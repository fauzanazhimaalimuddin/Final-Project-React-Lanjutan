// TODO: answer here
import React from "react";
import { Box, Text } from "@chakra-ui/react";

const Footer = () => {
    return (
      <Box
        className="footer"
        bg="gray.200"
        py={4}
        textAlign="center"
        data-testid="footer"
      >
        <Text className="studentName" data-testid="studentName">
          Maulana Fiqri Nurul Fawaid
        </Text>
        <Text className="studentId" data-testid="studentId">
          FE4486647
        </Text>
      </Box>
    );
  };
  
  export default Footer;
