const url = "YOURDEPLOYURL" // TODO: replace this
const studentName = "YOURNAME" // TODO: replace this
const studentId = "YOURSTUDENTID" // TODO: replace this

export { url, studentName, studentId }